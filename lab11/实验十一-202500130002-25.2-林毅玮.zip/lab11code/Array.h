#ifndef ARRAY_H
#define ARRAY_H
#include <cassert>

template<typename T>
class Array {
private:
    T* list;
    int size;
    
public:
    Array(int sz = 50) : size(sz) { 
        list = new T[size]; 
    }

    ~Array() {
        delete[] list;
    }

    T& operator[](int n) {
        assert(n >= 0 && n < size);
        return list[n];
    }

    const T* operator[](int n) const {
        assert(n >= 0 && n < size);
        return &list[n];
    }
    
    operator T*() {
        return list;
    }

    operator const T*() const {
        return list;
    }

    int getSize() const {
        return size;
    }
};

#endif