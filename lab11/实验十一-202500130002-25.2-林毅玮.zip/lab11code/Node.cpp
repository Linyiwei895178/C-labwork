#include <iostream>
#include "Node.h"
using namespace std;

int main() {
    Node<int>* head = new Node<int>(1);
    head->insertAfter(new Node<int>(2));
    head->next->insertAfter(new Node<int>(3));

    Node<int>* p = head;
    while (p) {
        cout << p->data << " ";
        p = p->next;
    }
    cout << endl;

    head->deleteAfter();
    p = head;
    while (p) {
        cout << p->data << " ";
        p = p->next;
    }

    return 0;
}