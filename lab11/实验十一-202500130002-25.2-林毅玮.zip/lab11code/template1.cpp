#include <cstdio>
#include <iostream>
using namespace std;

template<typename T>
void outputArray(const T* arr, int count) {
    for (int i = 0; i < count; ++i)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main()
{
    int a[] = {1, 2, 3};
    double b[] = {1.1, 2.2};
    char c[] = {'a', 'b'};
    outputArray(a, 3);
    outputArray(b, 2);
    outputArray(c, 2);

    return 0;
}