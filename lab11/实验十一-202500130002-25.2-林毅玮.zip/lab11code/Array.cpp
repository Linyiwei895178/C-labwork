#include <iostream>
#include "Array.h"
using namespace std;

void read(Array<int>& arr, int n) {
    for (int i = 0; i < n; ++i)
    {
        cin >> arr[i];
    }
}

int main() {
    Array<int> arr(5);
    cout << "请输入5个整数: ";
    read(arr, 5);
    cout << "你输入的数组是: ";
    for (int i = 0; i < 5; ++i) 
    {
        cout << arr[i] << " ";
    }
    cout << endl;
    return 0;
}