#include <iostream>
#include <string>
using namespace std;

template<typename T>
class Account {
protected:
    string id;
    T balance;
public:
    Account(string i, T b) : id(i), balance(b) {}
    virtual void deposit(T amt) { balance += amt; }
    virtual void withdraw(T amt) { balance -= amt; }
    virtual void show() const {
        cout << "Account ID: " << id << " balance: " << balance << endl;
   }
   virtual ~Account() {}
    
};

template<typename T>
class Savings : public Account<T> {
    private:
        T rate;
    public:
        Savings(string i, T b, T r) : Account<T>(i, b), rate(r) {}

        void settle() {
            this->balance *= (1 + rate);
        }
};

int main()
{
    Savings<double> s("S001", 1000, 0.015);
    s.deposit(500);
    s.settle();
    s.show();
    return 0;
}