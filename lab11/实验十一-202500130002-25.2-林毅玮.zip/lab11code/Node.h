#ifndef NODE_H
#define NODE_H

template<typename T>
class Node {
    public:

    T data;
    Node<T>* next;

    Node(const T& d, Node<T>* n = nullptr) : data(d), next(n) {}
    
    void insertAfter(Node<T>* p) {
        p->next = next;
        next = p;
    }

    Node<T>* deleteAfter() {
        Node<T>* p = next;
        if (p) next = p->next;
        return p;
    } 
};

#endif