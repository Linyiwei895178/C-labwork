#include <iostream>
using namespace std;

class Shape {
public:
    virtual double area() const = 0;
    virtual ~Shape() {}
};

class Circle : public Shape {
private:
    double r;

public:
    Circle(double ra) : r(ra) {}
    double area() const override { return 3.14 * r * r; }
};

class Rect : public Shape {
private:
    double w, h;
public:
    Rect(double wi, double he) : w(wi), h(he) {}
    double area() const override { return w * h; }
};

int main()
{
    Shape* s1 = new Circle(2);
    Shape* s2 = new Rect(3, 4);
    cout << "the area of circle is: " << s1->area() << endl;
    cout << "the area of rectangle is: " << s2->area() << endl;
    delete s1;
    delete s2;
    return 0;
}