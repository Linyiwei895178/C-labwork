#include <iostream>
#include <cstdlib>
using namespace std;

template<typename T>
class Store{
private:
    T item;
    bool hasVal;
public:
    Store() : hasVal(false) {}
    void put(const T& x) { item = x, hasVal = true; }
    T get() {
        if (!hasVal) {cout << "No data!" << endl; exit(1); }
        return item;
    }
    
};

struct Student { int id; double gpa; };

int main() {
    Store<int> s1; 
    s1.put(10);
    Store<double> s2;
    s2.put(3.14);
    Store<Student> s3;
    s3.put({1001, 3.8});
    cout << s1.get() << endl;
    cout << s2.get() << endl;
    cout << s3.get() << " " << s3.get().gpa << endl;
    return 0;
}
