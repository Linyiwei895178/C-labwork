// 2.继承中的同名隐藏问题
#include <iostream>
using namespace std;
class Base1
{
    public:
    int var;
    void fun()
    {
        cout << "Member of Base1" << endl;
    }
    void fun(int a)
    {
        cout << "Base1::fun(int) " << a << endl;
    }
};

class Base2
{
    public:
    int var;
    void fun()
    {
        cout << "Member of Base2" << endl;
    }
    void fun(int a, int b)
    {
        cout << "Base2::fun(int, int)" << a << "," << b << endl;
    }
};

class Derived : public Base1, public Base2
{
    public:
    int var;
    void fun()
    {
        cout << "Member of Derived" << endl;
    }
    void fun(int i)
    {
        cout << "Member of Derived i" << endl;
    }
    void fun(int i, int j)
    {
        cout << "Member of Derived i & j" << endl;
    }
};

int main()
{
    Derived d;
    d.fun(1);
    d.fun(2, 3);
    return 0;
}