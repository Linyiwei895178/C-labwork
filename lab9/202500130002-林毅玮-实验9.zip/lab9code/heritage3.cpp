// #include <iostream>
// #include <random>
// using namespace std;

// class Base0 
// {
//     public:
//     int var0;
//     void fun0()
//     {
//         cout << "Member of Base0" << endl;
//     }
// };

// class Base1 : public Base0
// {
//     public:
//     int var1;
// };

// class Base2 : public Base0
// {
//     public:
//     int var2;
// };

// class Derived : public Base1, public Base2
// {
//     int var;
//     void fun()
//     {
//         cout << "Member of Derived" << endl;
//     }
// };

// int main()
// {
//     Derived d;
//     d.Base1::var0 = 2;
//     d.Base1::fun0();
//     d.Base1::var0 = 3;
//     d.Base2::fun0();
//     cout << d.Base1::var0 << " " << d.Base2::var0 << endl;
//     // cout << d.var0 << " " << d.Base0::var0 << endl;
//     return 0;
// }




// -----------------------------------------------------
#include <iostream>
using namespace std;
class Base0 {
public:
    int var0;
    Base0(int var) : var0(var) {}
    void fun0() { cout << "Member of Base0" << endl; }
};
class Base1 : virtual public Base0 { // 虚继承
public:
    Base1(int var) : Base0(var) {}
    int var1;
};
class Base2 : virtual public Base0 { // 虚继承
public:
    Base2(int var) : Base0(var) {}
    int var2;
};
class Derived : public Base1, public Base2 {
public:
    Derived(int var) : Base0(var), Base1(var), Base2(var) {}
    int var;
    void fun() { cout << "Member of Derived" << endl; }
};
int main() {
    Derived d(1);
    cout << d.var0 << "  " << d.Base1::var0 << "  " << d.Base2::var0 << endl;
    d.var0 = 2;
    d.fun0();
    cout << d.var0 << "  " << d.Base1::var0 << "  " << d.Base2::var0 << endl;
    d.Base1::var0 = 1;
    d.Base2::var0 = 3;
    cout << d.var0 << "  " << d.Base1::var0 << "  " << d.Base2::var0 << endl;
    return 0;
}