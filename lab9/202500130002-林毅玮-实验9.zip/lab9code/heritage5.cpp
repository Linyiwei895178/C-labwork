#include <iostream>
using namespace std;
class Base1 
{
    public:
    void f()
    {
        cout << "Base1::f" << endl;
    }
};

class Base2
{
    public:
    void g()
    {
        cout << "Base2::g" << endl;
    }
};

class Derived : public Base1, public Base2 
{
    public:
    void h()
    {
        cout << "Derived::h" << endl;
    }
};

int main()
{
    Derived* pd = new Derived();
    Base2* pb = static_cast<Base2*>(pd);
    pb->g();

    void* pv  = pd;
    Base2 *pb2 = static_cast<Base2*>(pv);
    pb2->g();

    delete pd;
    return 0;
}