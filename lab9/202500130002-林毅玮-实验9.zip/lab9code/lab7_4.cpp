#include <iostream>
#include <string>
using namespace std;
class Person {
protected:
    string name;
    int age;
public:
    Person(string n, int a) : name(n), age(a) {}
    void show() { cout << "Name: " << name << ", Age: " << age << endl; }
};
class Student : public Person {
protected:
    string id;
public:
    Student(string n, int a, string i) : Person(n, a), id(i) {}
    void show() {
        Person::show();
        cout << "ID: " << id << endl;
    }
};
class Teacher : public Person {
protected:
    string title;
public:
    Teacher(string n, int a, string t) : Person(n, a), title(t) {}
    void show() {
        Person::show();
        cout << "Title: " << title << endl;
    }
};
class TA : public Student, public Teacher {
public:
    TA(string n, int a, string i, string t) : Person(n, a), Student(n,a,i), Teacher(n,a,t) {}
    void show() {
        Student::show();
        cout << "Title: " << title << endl;
    }
};
int main() {
    TA ta("Li", 25, "2026001", "Assistant");
    ta.show();
    return 0;
}