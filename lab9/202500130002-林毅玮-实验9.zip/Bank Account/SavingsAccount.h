#pragma once

#include "Account.h"
#include "Accumulator.h"

class SavingsAccount : public Account {
    private:
    Accumulator acc;
    double rate;
    
    public:
    SavingsAccount(const Date& d, const string &i, double r);

    void deposit(const Date& d, double amt, const string& desc) override;

    void withdraw(const Date& d, double amt, const string& desc) override;

    void settle(const Date& d) override;
};