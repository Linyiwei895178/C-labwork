#pragma once

#include "Account.h"
#include "Accumulator.h"

class CreditAccount : public Account
{
    private:
    Accumulator acc;
    double credit;
    double rate;
    double fee;
    double getDebt() const
    {
        return getBalance() < 0 ? getBalance() : 0;
    }

    public:
    CreditAccount(const Date& d, const string &i, double c, double r, double f);
    void deposit(const Date& d, double amt, const string& desc) override;
    void withdraw(const Date& d, double amt, const string& desc) override;
    void settle(const Date& d) override;
    void show() const override;
};
