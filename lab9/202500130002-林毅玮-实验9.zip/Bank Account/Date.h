
#pragma once

#include <iostream>
using namespace std;

class Date 
{
    private:
    int year, month, day;
    int totalDays;

    public:
    Date(int y, int m = 0, int d = 0);

    int distance(const Date& other) const;

    void show() const;

    int getYear() const 
    {
        return year;
    }
};
