#include "Account.h"
#include <iomanip>

double Account::total = 0;

Account::Account(const Date& d, const string &i) : id(i), balance(0)
{
    d.show();
    cout << "\t#" << id << " created" << endl;
}

void Account::record(const Date& d, double amt, const string &desc)
{
    amt = floor(amt * 100 + 0.5) / 100;
    balance += amt;
    total += amt;
    d.show();
    cout << "\t#" << id << "\t" << fixed << setprecision(2) 
        << amt << "\t" << balance << "\t" << desc << endl;
}

void Account::error(const string &msg) const {
    cout << "Error(#" << id << "): " << msg << endl;
}

void Account::show() const {
    cout << id << "\tBalance: " << fixed << setprecision(2) << balance;
}
