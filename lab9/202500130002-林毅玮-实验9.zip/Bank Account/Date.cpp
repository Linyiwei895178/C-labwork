#include "Date.h"

Date::Date(int y, int m, int d) : year(y), month(m), day(d)
{
    totalDays = y * 365 + m * 30 + d;
}

int Date::distance(const Date& other) const
{
    return abs(totalDays - other.totalDays);
}

void Date::show() const 
{
    cout << year << "-" << month << "-" << day;
}