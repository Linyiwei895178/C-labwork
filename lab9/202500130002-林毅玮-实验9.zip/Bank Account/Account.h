#pragma once

#include <string>
#include "Date.h"
#include <iostream>
#include <cmath>
using namespace std;

class Account
{
    protected:
    string id;
    double balance;
    static double total;

    void record(const Date& d, double amt, const string& desc);

    void error(const string &msg) const;

    public:
    Account(const Date& d, const string &i);
    
    virtual ~Account() {}

    virtual void deposit(const Date& d, double amt, const string &desc) = 0;

    virtual void withdraw(const Date& d, double amt, const string& desc) = 0;

    virtual void settle(const Date &d) = 0;

    string getId() const
    {
        return id;
    }

    double getBalance() const
    {
        return balance;
    }

    static double getTotal()
    {
        return total;
    }

    virtual void show() const;
};