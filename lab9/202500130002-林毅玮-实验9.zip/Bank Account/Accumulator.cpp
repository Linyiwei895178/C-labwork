#include "Accumulator.h"
#include "Date.h"
#include <immintrin.h>

Accumulator::Accumulator(const Date& d, double v) : lastDate(d), value(v), sum(0) {}

double Accumulator::getSum(const Date& d) const 
{
    return sum + value * d.distance(lastDate);
}

void Accumulator::change(const Date&d, double v)
{
    sum = getSum(d);
    lastDate = d;
    value = v;
}

void Accumulator::reset(const Date& d, double v)
{
    lastDate = d;
    value = v;
    sum = 0;
}