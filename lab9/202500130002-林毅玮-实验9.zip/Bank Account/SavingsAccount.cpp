#include "SavingsAccount.h"

SavingsAccount::SavingsAccount(const Date& d, const string &i, double r) : Account(d, i), rate(r), acc(d, 0) {}

void SavingsAccount::deposit(const Date& d, double amt, const string& desc) {
    record(d, amt, desc);
    acc.change(d, getBalance());
}

void SavingsAccount::withdraw(const Date& d, double amt, const string& desc)
{
    if (amt > getBalance())
    {
        error("not enough money");
    }
    else {
        record(d, -amt, desc);
        acc.change(d, getBalance());
    }
}

void SavingsAccount::settle(const Date& d) {
    double interest = acc.getSum(d) * rate / 365;
    if (interest != 0)
    {
        record(d, interest, "interest");
    }
    acc.reset(d, getBalance());
}
