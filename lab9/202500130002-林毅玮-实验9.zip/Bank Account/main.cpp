#include <iostream>
#include "SavingsAccount.h"
#include "CreditAccount.h"
using namespace std;

int main() {
    // 初始化日期
    Date date(2008, 11, 1);
    // 创建储蓄账户
    SavingsAccount sa1(date, "S3755217", 0.015);
    SavingsAccount sa2(date, "02342342", 0.015);
    // 创建信用账户
    CreditAccount ca(date, "C5392394", 10000, 0.0005, 50);

    // 业务操作
    sa1.deposit(Date(2008, 11, 5), 5000, "salary");
    ca.withdraw(Date(2008, 11, 15), 2000, "buy a cell");
    sa2.deposit(Date(2008, 11, 25), 10000, "sell stock");

    // 月度/年度结算
    ca.settle(Date(2008, 12, 1));
    ca.deposit(Date(2008, 12, 1), 2016, "repay");
    sa1.deposit(Date(2008, 12, 5), 5500, "salary");
    sa1.settle(Date(2009, 1, 1));
    sa2.settle(Date(2009, 1, 1));
    ca.settle(Date(2009, 1, 1));

    // 输出结果
    cout << endl;
    sa1.show(); cout << endl;
    sa2.show(); cout << endl;
    ca.show(); cout << endl;
    cout << "Total: " << Account::getTotal() << endl;

    return 0;
}