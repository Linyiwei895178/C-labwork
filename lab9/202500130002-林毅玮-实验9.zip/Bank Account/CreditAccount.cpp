#include "CreditAccount.h"
#include "Date.h"

CreditAccount::CreditAccount(const Date& d, const string& i, double c, double r, double f) : Account(d, i), credit(c), rate(r), fee(f), acc(d, 0) {}

void CreditAccount::deposit(const Date& d, double amt, const string& desc)
{
    record(d, amt, desc);
    acc.change(d, getDebt());
}

void CreditAccount::withdraw(const Date& d, double amt, const string& desc) 
{
    if (amt - getBalance() > credit)
    {
        error("not enough creditl");
    }
    else  
    {
        record(d, -amt, desc);
        acc.change(d, getDebt());
    }
}

void CreditAccount::settle(const Date& d)
{
    double interest = acc.getSum(d) * rate;
    if (interest != 0)
    {
        record(d, interest, "interest");
    }
    if (d.distance(Date(d.getYear(), 1, 1)) == 0)
    {
        record(d, -fee, "annual fee");
    }
    acc.reset(d, getDebt());
}

void CreditAccount::show() const 
{
    Account::show();
    cout << "\tAvailable credit:" << credit + (getBalance() < 0 ? getBalance() : 0);
}