#pragma once

#include "Date.h"

class Accumulator
{
    private:
    Date lastDate;
    double value;
    double sum;

    public:
    Accumulator(const Date& d, double v);
    double getSum(const Date& d) const;
    void change(const Date&d, double v);
    void reset(const Date&d, double v);
};