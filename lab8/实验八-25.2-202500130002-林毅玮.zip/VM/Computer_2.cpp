//
// Created by LYW on 2026/5/7.
//

#include "Computer_2.h"
#include <iostream>
using namespace std;

Computer_2::Computer_2(string cu_name, string alu_name, int mem_size, string in_name, string out_name) : Computer(cu_name, alu_name, mem_size, in_name, out_name) {}

void Computer_2::run(int inst_list[], int inst_len)
{
    for (int i = 0; i < inst_len; i++)
    {
        memory->write(i, inst_list[i]);
    }
    cu->setPC(0);

    while (true)
    {
        int pc = cu->getPC();
        int inst = memory->read(pc);
        int opcode, addr;
        splitInstruction(inst, opcode, addr);

        switch (opcode)
        {
        case 10:
            {
                int val = inDevice->input();
                memory->write(addr, val);
                break;
            }
        case 11:
            {
                int val = memory->read(addr);
                outDevice->output(val);
                break;
            }
        case 20:
            {
                int val = memory->read(addr);
                alu->setAC(val);
                break;
            }
        case 21:
            {
                memory->write(addr, alu->getAC());
                break;
            }
        case 30:
            {
                alu->add(memory->read(addr));
                break;
            }
        case 31:
            {
                alu->sub(memory->read(addr));
                break;
            }
        case 32:
            {
                alu->mul(memory->read(addr));
                break;
            }
        case 33:
            {
                alu->div(memory->read(addr));
                break;
            }
        case 40:
            {
                cu->setPC(addr);
                continue;
            }
        case 43:
            {
                cout << "the Computer_2 program halts" << endl;
                return;
            }
        default:
            {
                cout << "unknown instruction: " << opcode << endl;
                return;
            }
        }
        cu->intcPC();
    }
}