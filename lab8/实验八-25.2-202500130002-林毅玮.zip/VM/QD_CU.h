//
// Created by LYW on 2026/5/7.
//

#ifndef VM_QD_CU_H
#define VM_QD_CU_H

class QD_CU
{
private:
    int PC;
public:
    QD_CU();
    int getPC();
    void setPC(int addr);
    void intcPC();
};

#endif //VM_QD_CU_H
