//
// Created by LYW on 2026/5/7.
//

#include "Computer.h"
#include <iostream>
using namespace std;

Computer::Computer(string cu_name, string alu_name, int mem_size, string in_name, string out_name) : cuName(cu_name), aluName(alu_name)
{
    cu = new QD_CU();
    alu = new QD_ALU();
    memory = new QD_Memory(mem_size);
    inDevice = new QD_In(in_name);
    outDevice = new QD_Out(out_name);
}

Computer::~Computer()
{
    delete cu;
    delete alu;
    delete memory;
    delete inDevice;
    delete outDevice;
}

void Computer::splitInstruction(int inst, int &opcode, int &addr)
{
    opcode = inst / 100;
    addr = inst % 100;
}

void Computer::run(int inst_list[], int inst_len)
{
    for (int i = 0; i < inst_len; i++)
    {
        memory->write(i, inst_list[i]);
    }
    cu->setPC(0);

    while (true)
    {
        int pc = cu->getPC();
        int inst = memory->read(pc);
        int opcode, addr;
        splitInstruction(inst, opcode, addr);

        switch (opcode)
        {
        case 10:
            {
                int val = inDevice->input();
                memory->write(addr, val);
                break;
            }
        case 11:
            {
                int val = memory->read(addr);
                outDevice->output(val);
                break;
            }
        case 20:
            {
                int val = memory->read(addr);
                alu->setAC(val);
                break;
            }
        case 21:
            {
                memory->write(addr, alu->getAC());
                break;
            }
        case 30:
            {
                int val = memory->read(addr);
                alu->add(val);
                break;
            }
        case 31:
            {
                int val = memory->read(addr);
                alu->sub(val);
                break;
            }
        case 40:
            {
                cu->setPC(addr);
                continue;
            }
        case 43:
            {
                cout << "the Computer program halts" << endl;
                return;
            }
        default:
            cout << "unknown instruction: " << opcode << endl;
        }
        cu->intcPC();
    }
}