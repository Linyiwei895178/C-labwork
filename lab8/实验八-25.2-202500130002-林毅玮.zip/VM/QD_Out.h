//
// Created by LYW on 2026/5/7.
//

#ifndef VM_QD_OUT_H
#define VM_QD_OUT_H

#include <string>
using namespace std;

class QD_Out
{
private:
    string name;
public:
    QD_Out(string device_name);
    void output(int value);
};

#endif //VM_QD_OUT_H
