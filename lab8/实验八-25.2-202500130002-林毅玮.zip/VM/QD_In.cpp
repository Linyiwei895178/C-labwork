//
// Created by LYW on 2026/5/7.
//

#include "QD_In.h"
#include <iostream>
using namespace std;

QD_In::QD_In(string device_name) : name(device_name) {}

int QD_In::input()
{
    int val;
    cout << "Please enter an integer: ";
    cin >> val;
    return val;
}