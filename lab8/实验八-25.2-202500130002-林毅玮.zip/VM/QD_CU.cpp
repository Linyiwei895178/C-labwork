//
// Created by LYW on 2026/5/7.
//

#include "QD_CU.h"
QD_CU::QD_CU() : PC(0) {}

int QD_CU::getPC()
{
    return PC;
}

void QD_CU::setPC(int addr)
{
    PC = addr;
}

void QD_CU::intcPC()
{
    PC++;
}
