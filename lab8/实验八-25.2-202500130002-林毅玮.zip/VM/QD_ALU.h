//
// Created by LYW on 2026/5/7.
//

#ifndef VM_QD_ALU_H
#define VM_QD_ALU_H

class QD_ALU
{
private:
    int AC;
public:
    QD_ALU();
    void setAC(int value);
    int getAC();
    void add(int value);
    void sub(int value);
    void mul(int value);
    void div(int value);
};

#endif //VM_QD_ALU_H
