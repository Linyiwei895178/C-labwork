//
// Created by LYW on 2026/5/7.
//

#include "QD_Memory.h"
#include <stdexcept>

QD_Memory::QD_Memory(int mem_size) : size(mem_size)
{
    memory.resize(mem_size, 0);
}

void QD_Memory::write(int addr, int value)
{
    if (addr < 0 || addr >= size)
    {
        throw runtime_error("cross the boundry of the memory address");
    }
    memory[addr] = value;
}

int QD_Memory::read(int addr)
{
    if (addr < 0 || addr >= size)
    {
        throw runtime_error("cross the boundry of the memory address");
    }
    return memory[addr];
}

int QD_Memory::getSize()
{
    return size;
}