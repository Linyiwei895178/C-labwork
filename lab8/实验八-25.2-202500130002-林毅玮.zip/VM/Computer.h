//
// Created by LYW on 2026/5/7.
//

#ifndef VM_COMPUTER_H
#define VM_COMPUTER_H

#include "QD_Memory.h"
#include "QD_CU.h"
#include "QD_ALU.h"
#include "QD_In.h"
#include "QD_Out.h"
#include <string>
using namespace std;

class Computer
{
protected:
    QD_CU* cu;
    QD_ALU* alu;
    QD_Memory* memory;
    QD_In* inDevice;
    QD_Out* outDevice;
    string cuName;
    string aluName;

    void splitInstruction(int inst, int& opcode, int &addr);
public:
    Computer(string cu_name, string alu_name, int mem_size, string in_name, string out_name);
    virtual ~Computer();
    virtual void run(int inst_list[], int inst_len);
};

#endif //VM_COMPUTER_H
