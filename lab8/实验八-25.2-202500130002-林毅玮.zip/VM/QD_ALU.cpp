//
// Created by LYW on 2026/5/7.
//

#include "QD_ALU.h"
#include <stdexcept>
using namespace std;

QD_ALU::QD_ALU() : AC(0) {}

void QD_ALU::setAC(int value)
{
    AC = value;
}

int QD_ALU::getAC()
{
    return AC;
}

void QD_ALU::add(int value)
{
    AC += value;
}

void QD_ALU::sub(int value)
{
    AC -= value;
}

void QD_ALU::mul(int value)
{
    AC *= value;
}

void QD_ALU::div(int value)
{
    if (value == 0)
    {
        throw runtime_error("the error that num is divided by zero");
    }
    AC /= value;
}

