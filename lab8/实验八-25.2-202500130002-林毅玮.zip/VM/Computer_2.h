//
// Created by LYW on 2026/5/7.
//

#ifndef VM_COMPUTER_2_H
#define VM_COMPUTER_2_H

#include "Computer.h"
class Computer_2 : public Computer
{
public:
    Computer_2(string cu_name, string alu_name, int mem_size, string in_name, string out_name);
    void run(int inst_list[], int inst_len) override;
};

#endif //VM_COMPUTER_2_H
