#include "Computer.h"
#include "Computer_2.h"
#include <iostream>
using namespace std;

int main() {
        // ==================== 一代机 全用例测试 ====================
        std::cout << "========== 一代机：两数相加 ==========" << std::endl;
        Computer vm1("青芯CU1", "青芯ALU1", 1024, "输入1", "输出1");
        int inst1[] = {1007,1008,2007,3008,2109,1109,4010,0,0,0,4300};
        vm1.run(inst1, sizeof(inst1)/sizeof(int));

        std::cout << "\n========== 一代机：两数相减 ==========" << std::endl;
        Computer vm1_sub("青芯CU1", "青芯ALU1", 1024, "输入1", "输出1");
        int inst_sub[] = {1007,1008,2007,3108,2109,1109,4010,0,0,0,4300};
        vm1_sub.run(inst_sub, sizeof(inst_sub)/sizeof(int));

        std::cout << "\n========== 一代机：单数据读写 ==========" << std::endl;
        Computer vm1_rw("青芯CU1", "青芯ALU1", 1024, "输入1", "输出1");
        int inst_rw[] = {1007,1107,4003,4300};
        vm1_rw.run(inst_rw, sizeof(inst_rw)/sizeof(int));

        // ==================== 二代机 全用例测试 ====================
        std::cout << "\n========== 二代机：两数相乘 ==========" << std::endl;
        Computer_2 vm2_mul("青芯CU2", "青芯ALU2", 1024, "输入2", "输出2");
        int inst_mul[] = {1007,1008,2007,3208,2109,1109,4010,0,0,0,4300};
        vm2_mul.run(inst_mul, sizeof(inst_mul)/sizeof(int));

        std::cout << "\n========== 二代机：两数相除 ==========" << std::endl;
        Computer_2 vm2_div("青芯CU2", "青芯ALU2", 1024, "输入2", "输出2");
        int inst_div[] = {1007,1008,2007,3308,2109,1109,4010,0,0,0,4300};
        vm2_div.run(inst_div, sizeof(inst_div)/sizeof(int));

        std::cout << "\n========== 二代机：混合运算 ==========" << std::endl;
        Computer_2 vm2_mix("青芯CU2", "青芯ALU2", 1024, "输入2", "输出2");
        int inst_mix[] = {1007,1008,1009,2007,3008,3209,2110,1110,4011,4300};
        vm2_mix.run(inst_mix, sizeof(inst_mix)/sizeof(int));

        std::cout << "\n======================================" << std::endl;
        std::cout << "所有测试用例执行完成！" << std::endl;
        return 0;
}