//
// Created by LYW on 2026/5/7.
//

#ifndef VM_QD_LN_H
#define VM_QD_LN_H

#include <string>
using namespace std;

class QD_In
{
private:
    string name;
public:
    QD_In(string device_name);
    int input();
};

#endif //VM_QD_LN_H
