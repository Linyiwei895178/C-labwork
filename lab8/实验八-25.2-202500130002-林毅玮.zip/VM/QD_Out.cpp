//
// Created by LYW on 2026/5/7.
//

#include "QD_Out.h"
#include <iostream>
using namespace std;

QD_Out::QD_Out(string device_name) : name(device_name) {}

void QD_Out::output(int value)
{
    cout << "the output is: " << value << endl;
}

