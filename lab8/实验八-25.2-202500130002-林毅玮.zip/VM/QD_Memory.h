//
// Created by LYW on 2026/5/7.
//

#ifndef VM_QD_MEMORY_H
#define VM_QD_MEMORY_H

#include <iostream>
#include <vector>
using namespace std;

class QD_Memory
{
private:
    vector<int> memory;
    int size;
public:
    QD_Memory(int mem_size);
    void write(int addr, int value);
    int read(int addr);
    int getSize();
};

#endif //VM_QD_MEMORY_H
