#include <iostream>
using namespace std;

class BaseClass {
    public:
    virtual void fn1();
    void fn2();
};

void BaseClass::fn1()
{
    cout << "the call of the virtual function fn1()" << endl;
}

void BaseClass::fn2() {
    cout << "the call of the non virtual function fn2()" << endl;
}

class DerivedClass : public BaseClass {
    public:
    void fn1();
    void fn2();
};

void DerivedClass::fn1() {
    cout << "the call of the derived function fn1()" << endl;
}

void DerivedClass::fn2() {
    cout << "the call of the derived function fn2()" << endl;
}

int main()
{
    DerivedClass aDerivedClass;
    DerivedClass * pDerivedClass = &aDerivedClass;

    BaseClass *pBaseClass = &aDerivedClass;

    pBaseClass->fn1();
    pBaseClass->fn2();
    pDerivedClass->fn1();
    pDerivedClass->fn2();
    return 0;
}

































// #include <iostream>
// using namespace std;

// class Base {
//     public:
//     virtual void fun() {
//         cout << "Base::fun()" << endl;
//     }
// };

// class Derived : public Base {
//     public:
//     void fun() override {
//         cout << "Derived::fun()" << endl;
//     }
// };

// int main()
// {
//     Base  b;
//     Derived d;

//     cout << "the call of the base" << endl;
//     b.fun();

//     Base* pb = &d;
//     cout << "the base pointer point to the derived call: "  << endl;
//     pb->fun();

//     return 0;
// }