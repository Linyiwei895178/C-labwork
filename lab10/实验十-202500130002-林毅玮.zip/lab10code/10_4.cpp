#include <iostream>
#include <thread>
using namespace std;

class Point {
    private:
    int x, y;

    public:
    Point(int x = 0, int y = 0) : x(x), y(y) {}

    void show() const {
        cout << "(" << x << ", " << y << ")" << endl;
    }

    Point& operator++() {
        x++;
        y++;
        return *this;
    }

    Point operator++(int) {
        Point temp = *this;
        x++;
        y++;
        return temp;
    }
};

int main()
{
    Point p1;
    cout << "before ++++p1: ";
    ++++p1;
    p1.show();

    Point p2;
    cout << "behind p2++: ";
    p2++;
    p2.show();

    return 0;
}