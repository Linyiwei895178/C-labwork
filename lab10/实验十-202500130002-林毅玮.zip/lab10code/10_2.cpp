#include <iostream>
using namespace std;

class Clock {
    private:
    int hour, minute, second;

    public:
    Clock(int h = 0, int m = 0, int s = 0) : hour(h), minute(m), second(s) {}

    void showTime() const {
        cout << hour << ":" << minute << ":" << second << endl;
    }

    Clock& operator++() {
        second++;
        if (second >= 60) {
            second -=60;
            minute++;
            if (minute >= 60) {
                minute -= 60;
                hour = (hour + 1) % 24;
            }
        }
        return *this;
    }

    Clock operator++(int) {
        Clock old = *this;
        ++(*this);
        return old;
    }
};

int main()
{
    Clock myclock(23, 59, 59);
    cout << "Initial time: ";
    myclock.showTime();

    cout << "behind++: ";
    myclock++.showTime();
    cout << "behing++ time: ";
    myclock.showTime();

    cout << "before++: ";
    (++myclock).showTime();
    cout << "before++ time:";
    (++++myclock).showTime();
    
    return 0;
}
