#include <complex>
#include <iostream>
using namespace std;

class Complex 
{
    private:
    double real, imag;

    public:

    Complex(double r = 0.0, double i = 0.0) : real(r), imag(i) {}

    Complex operator+(const Complex& c2) const {
        return Complex(real + c2.real, imag + c2.imag);
    }

    void display() const {
        cout << "(" << real << ", " << imag << ")" << endl;
    }

};

int main()
{
    Complex c1(5,4), c2(2, 10), c3;

    c3 = c1 + c2;
    cout << "c3 = c1 + c2 = " ;
    c3.display();

    // Complex operator+(Complex& c2);
    // c3 = 1 + c2;
    // cout << "c3 = 1 + c2 = ";
    // c2.display();

    return 0;
}