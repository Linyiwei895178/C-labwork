#include <iostream>
using namespace std;

class Complex {
private:
    double real, imag;
    
public:
    Complex(double r = 0.0, double i = 0.0) : real(r), imag(i) {}

    friend Complex operator+(const Complex& c1, const Complex& c2);
    friend ostream& operator<<(ostream &out, const Complex& c);

};

Complex operator+(const Complex& c1, const Complex& c2) {
    return Complex(c1.real + c2.real, c1.imag + c2.imag);
}

ostream& operator<<(ostream &out, const Complex& c) {
    out << "(" << c.real << ", " << c.imag << ")";
    return out;
}

int main() {
    Complex c1(5, 4), c2(2, 10);
    cout << "c1 = " << c1 << endl;
    cout << "c2 = " << c2 << endl;

    Complex c3 = c1 + c2;
    cout << "c1 + c2 = " << c3 << endl;

    // 混合运算：转换构造函数生效
    Complex c4 = 1.0 + c2;
    Complex c5 = c1 + 2.0;
    cout << "1.0 + c2 = " << c4 << endl;
    cout << "c1 + 2.0 = " << c5 << endl;

    return 0;
}