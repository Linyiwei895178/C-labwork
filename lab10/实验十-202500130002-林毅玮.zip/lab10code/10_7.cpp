#include <iostream>
using namespace std;

class Base {
    public:
    ~Base();
};

Base::~Base() {
    cout << "Base destructor" << endl;
}

class Derived : public Base {
    public:
    Derived();
    ~Derived();

    private:
    int *p;
};

Derived::Derived() {
    p = new int(0);
}

Derived::~Derived() {
    cout << "Derived destructor" << endl;
    delete p;
}

void fun(Base* b)
{
    delete b;
}

int main() 
{
    Base *b = new Derived();
    fun(b);
    cout << endl;

    cout << "-----a-----" << endl;
    Base b1 = Derived();
    cout << endl;

    cout << "-----b-----" << endl;
    Derived d1;   
    fun(&d1);

    return 0;
}

// #include <iostream>
// using namespace std;

// class Base {
//     public:
//     Base() {
//         cout << "Base construction" << endl;
//     }

//     virtual ~Base() {
//         cout << "Base destruciton" << endl;
//     }
// };

// class Derived : public Base {
//     private:
//     int *p;
    
//     public:
//     Derived() {
//         p = new int(0);
//         cout << "Derived construciton" << endl;
//     }
//     ~Derived() {
//         delete p;
//         cout << "Derived destruction" << endl;
//     }
// };

// int main()
// {
//     Base* p = new Derived();
//     delete p;
//     return 0;
// }