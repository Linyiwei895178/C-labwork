#include <iostream>
using namespace std;

class Base {
    public:
    void show() {
        cout << "Base show()" << endl;
    }

    void show(int i) {
        cout << "Base show(int)" << endl;
    }

    virtual void fun() const {
        cout << "Base fun()" << endl;
    }

    virtual void fun(double r1, double r2, double r3) const {}
    
    virtual void fun(int a, int b = 2) const {
        cout << "Base a: " << a << " b:" << b << endl;
    }

};

class Derived : public Base {
    public:
    void show() {
        cout << "Derived show()" << endl;
    }

    virtual void fun() const {
        cout << "Derived show()" << endl;
    }
    virtual void fun(int a, int b = 3) const {
        cout << "Derived fun a:" << a << " b:" << b << endl;
    }
};

int main() {
    Base b;
    Derived d;
    Derived* pd = &d;
    Base* pb = &d;

    cout << "1. the object call: " << endl;
    d.show();
    d.Base::show(1);
    d.fun();
    cout << endl;

    cout << "2. the object cut: " << endl;
    b = d;
    b.show();
    b.fun();
    cout << endl;

    cout << "3. the pointer call: " << endl;
    pd->fun(8);
    pb->fun(8);

    return 0;
}