#pragma once

#include <iostream>
#include <ostream>
using namespace std;
#include <vector>
#include <algorithm>

class BigInt {
    public:
    vector<int> digits;
    static const int MAX_BIT = 100;

    void trim();
    int compare(const BigInt& other) const;

    public:
    
    BigInt();
    BigInt(const string& s);

    BigInt operator+(const BigInt& other) const;
    BigInt operator-(const BigInt& other) const;
    BigInt operator*(const BigInt& other) const;
    BigInt operator/(const BigInt& other) const;

    friend ostream& operator<<(ostream& out, const BigInt& num);    
};