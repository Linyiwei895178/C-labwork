#include "BigInt.h"

// 去除前导零
void BigInt::trim() {
    while (digits.size() > 1 && digits.back() == 0)
        digits.pop_back();
}

// 比较大小
int BigInt::compare(const BigInt& other) const {
    if (digits.size() != other.digits.size())
        return digits.size() > other.digits.size() ? 1 : -1;
    for (int i = digits.size() - 1; i >= 0; --i)
        if (digits[i] != other.digits[i])
            return digits[i] > other.digits[i] ? 1 : -1;
    return 0;
}

// 默认构造：初始化为0
BigInt::BigInt() {
    digits.push_back(0);
}

// 字符串构造
BigInt::BigInt(const std::string& s) {
    digits.clear();
    // 逆序存入
    for (auto it = s.rbegin(); it != s.rend(); ++it)
        digits.push_back(*it - '0');
    trim();
}

// 加法
BigInt BigInt::operator+(const BigInt& other) const {
    BigInt res;
    res.digits.clear();
    int carry = 0, i = 0;
    while (i < digits.size() || i < other.digits.size() || carry) {
        int sum = carry;
        if (i < digits.size()) sum += digits[i];
        if (i < other.digits.size()) sum += other.digits[i];
        carry = sum / 10;
        res.digits.push_back(sum % 10);
        ++i;
    }
    res.trim();
    return res;
}

// 减法（保证被减数≥减数）
BigInt BigInt::operator-(const BigInt& other) const {
    BigInt res;
    res.digits.clear();
    if (compare(other) < 0) {
        std::cout << "减法错误：被减数小于减数" << std::endl;
        return BigInt();
    }
    int borrow = 0, i = 0;
    while (i < digits.size()) {
        int sub = digits[i] - borrow;
        if (i < other.digits.size()) sub -= other.digits[i];
        if (sub < 0) { sub += 10; borrow = 1; }
        else borrow = 0;
        res.digits.push_back(sub);
        ++i;
    }
    res.trim();
    return res;
}

// 乘法
BigInt BigInt::operator*(const BigInt& other) const {
    BigInt res;
    res.digits.assign(digits.size() + other.digits.size(), 0);
    for (int i = 0; i < digits.size(); ++i) {
        int carry = 0;
        for (int j = 0; j < other.digits.size() || carry; ++j) {
            int mul = res.digits[i + j] + digits[i] * (j < other.digits.size() ? other.digits[j] : 0) + carry;
            carry = mul / 10;
            res.digits[i + j] = mul % 10;
        }
    }
    res.trim();
    return res;
}

// 除法（返回商，忽略余数）
BigInt BigInt::operator/(const BigInt& other) const {
    BigInt res, temp;
    res.digits.resize(digits.size(), 0);
    if (compare(other) < 0) return BigInt();
    for (int i = digits.size() - 1; i >= 0; --i) {
        temp.digits.insert(temp.digits.begin(), digits[i]);
        temp.trim();
        int cnt = 0;
        while (temp.compare(other) >= 0) {
            temp = temp - other;
            ++cnt;
        }
        res.digits[i] = cnt;
    }
    res.trim();
    return res;
}

// 输出
std::ostream& operator<<(std::ostream& out, const BigInt& num) {
    for (int i = num.digits.size() - 1; i >= 0; --i)
        out << num.digits[i];
    return out;
}