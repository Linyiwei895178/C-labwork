#include "BigInt.h"
#include <iostream>

int main() {
    BigInt a("9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999");
    BigInt b("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678");

    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "a + b = " << a + b << endl;
    cout << "a - b = " << a - b << endl;
    cout << "a * b = " << a * b << endl;
    cout << "a / b = " << a / b << endl;

    return 0;
}